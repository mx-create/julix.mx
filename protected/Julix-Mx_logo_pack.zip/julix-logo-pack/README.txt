JULIX LOGO PACK
===============

Colours
  Black  #0A0A0A   RGB 10 10 10
  Gold   #D9A441   RGB 217 164 65
  White  #FFFFFF   RGB 255 255 255

Folders
  vector/       SVG logos in white, black and gold. Scale to any size.
                Use these for print, merch, banners and flyers.
  png/          Transparent PNGs at 1000, 2000 and 4000 px wide.
                Use these for posters, event listings and video overlays.
  backgrounds/  Logo on solid black, white or gold (2400 x 1200 JPG).
                For promoters and listings that cannot use transparency.
  social/       Ready-sized profile pictures (1080 x 1080), X/Twitter banner,
                YouTube cover, Facebook cover and Instagram story.

Usage
  - Use white or gold on dark backgrounds, and black on light or gold backgrounds.
  - Keep clear space around the logo of at least the height of the "I".
  - Do not stretch, rotate, recolour outside the palette above, add effects,
    or redraw the letters.
  - The name is written "Julix" in text.

Bookings and press: julix.mx@outlook.com
(c) Julix&Mx. All rights reserved.
